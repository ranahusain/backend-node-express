const express = require("express");
const app = express();
const connectDB = require("./db");
const students = require("./routes/students");
const dotenv = require("dotenv");
const cors = require("cors");
const morgan = require("morgan");

dotenv.config();

const PORT = process.env.PORT || 5001;

app.use(express.json());
app.use(cors());
app.use(morgan("dev"));

connectDB();

app.use("/api/students", students);

app.get("/", (req, res) => {
  res.status(200).json({ message: "Student Management API is running" });
});

app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
